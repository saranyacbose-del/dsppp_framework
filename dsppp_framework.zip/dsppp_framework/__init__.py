"""
DSPPP Framework - Dynamic Semantic Personalized Path Planning
"""

__version__ = "1.0.0"
__author__ = "Saranya C, Janaki G"
